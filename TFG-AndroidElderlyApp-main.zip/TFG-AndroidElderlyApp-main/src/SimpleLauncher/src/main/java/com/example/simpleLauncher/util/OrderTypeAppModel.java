package com.example.simpleLauncher.util;

public enum OrderTypeAppModel {
    ORDER_BY_NAME, ORDER_BY_SHORTCUT_AND_NAME
}

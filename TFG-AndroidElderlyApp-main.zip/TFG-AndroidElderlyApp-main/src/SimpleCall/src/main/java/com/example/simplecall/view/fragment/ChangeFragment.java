package com.example.simplecall.view.fragment;

public interface ChangeFragment {
    public void change(int code);
}

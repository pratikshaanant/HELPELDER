package com.example.simplecall.event;

import com.example.simplecall.model.ContactModel;

public interface UpdateContact {
    void updateContact(ContactModel contactModel);
}
